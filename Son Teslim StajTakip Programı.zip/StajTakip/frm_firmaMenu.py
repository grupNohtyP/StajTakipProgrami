# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\ahmet\Desktop\StajTakip\ekranlar\menu.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import *
import sys

import frm_anasayfa
import frm_stajyerilan
import frm_stajyeralim

class Ui_Dialog(object):
    def setupUi(self, Dialog):

        def kapat():
            cevap=QMessageBox.question(Dialog,"Kapat","Kapatmak İstediğinize Emin misiniz?",\
                             QMessageBox.Yes | QMessageBox.No)
            if cevap == QMessageBox.Yes:
                window = QtWidgets.QMainWindow()
                ui = frm_anasayfa.Ana_MainWindow()
                ui.setupUi(window)
                window.show()
                Dialog.close()

        def ilan():
            window = QtWidgets.QMainWindow()
            ui = frm_stajyerilan.Ui_Dialog()
            ui.setupUi(window)
            window.show()
            Dialog.close()

        def stajyersec():
            window = QtWidgets.QMainWindow()
            ui = frm_stajyeralim.Ui_Dialog()
            ui.setupUi(window)
            window.show()
            Dialog.close()

        Dialog.setObjectName("Dialog")
        Dialog.resize(467, 101)
        self.pushButton = QtWidgets.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(10, 10, 161, 81))
        self.pushButton.setObjectName("pushButton")
        self.pushButton_2 = QtWidgets.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(180, 10, 171, 81))
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_4 = QtWidgets.QPushButton(Dialog)
        self.pushButton_4.setGeometry(QtCore.QRect(360, 10, 101, 81))
        self.pushButton_4.setObjectName("pushButton_4")
        Dialog.setWindowFlags(Qt.WindowType.WindowSystemMenuHint);

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

        self.pushButton_4.clicked.connect(kapat)
        self.pushButton.clicked.connect(ilan)
        self.pushButton_2.clicked.connect(stajyersec)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Firma Menüsü"))
        self.pushButton.setText(_translate("Dialog", "Stajyer Alım İlanı Ver"))
        self.pushButton_2.setText(_translate("Dialog", "Stajyer Seç"))
        self.pushButton_4.setText(_translate("Dialog", "Çıkış"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())

