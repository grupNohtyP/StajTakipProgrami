# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\ahmet\Desktop\StajTakip\ekranlar\defterler.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import *
import sys
import sqlite3
import datetime
import frm_ogrtMenu
global curs
global conn

conn=sqlite3.connect('stjyrtkp.sqlite')
curs=conn.cursor()

global ilanno
class Ui_Dialog(object):
    def setupUi(self, Dialog):

        def kapat():
            cevap=QMessageBox.question(Dialog,"Kapat","Kapatmak İstediğinize Emin misiniz?",\
                             QMessageBox.Yes | QMessageBox.No)
            if cevap== QMessageBox.Yes:
                window = QtWidgets.QMainWindow()
                ui = frm_ogrtMenu.Ui_Dialog()
                ui.setupUi(window)
                window.show()
                Dialog.close()

        def OGRTTCNOGETIR():
            curs.execute("SELECT ogretmen_oturum.ogrt_TcNo,ogretmen_bilgi.ogrt_AdSoyad FROM ogretmen_oturum,ogretmen_bilgi WHERE ogretmen_oturum.id = 1 \
                                and ogretmen_oturum.ogrt_TcNo=ogretmen_bilgi.ogrt_TcNo")
            deger=curs.fetchone()
            self.lblTcNo.setText("Tc No: " +str(deger[0]))
            self.lblAdSoyad.setText("Ad Soyad: " +str(deger[1]))
            return str(deger[0])
        

        def STAJYERLER():
            self.tblStajyerleriniz.clear()
            self.tblStajyerleriniz.setRowCount(0)

            veri=curs.execute("Select ilan_alim.ilan_id, ogrenci_bilgi.ogr_No,ogrenci_bilgi.ogr_AdSoyad,ilan_alim.ogr_TcNo,ogrenci_bilgi.ogr_Mail, \
                                stajyer_ilan.ilan_Mesaj,stajyer_ilan.staj_BasTarih,stajyer_ilan.staj_BitTarih, \
                                stajyer_ilan.firma_SicilNo, firma_bilgi.firma_Ad,firma_bilgi.firma_TelNo,firma_bilgi.firma_Mail \
                                from  ilan_alim, ogrenci_bilgi,stajyer_ilan,firma_bilgi \
                                WHERE ilan_alim.ogr_TcNo=ogrenci_bilgi.ogr_TcNo and ilan_alim.ilan_id=stajyer_ilan.ilan_id and stajyer_ilan.firma_SicilNo=firma_bilgi.firma_SicilNo")
            for satirIndeks, satirVeri in enumerate(veri):
                self.tblStajyerleriniz.insertRow(satirIndeks)
                for sutunIndeks, sutunVeri in enumerate (satirVeri):
                    self.tblStajyerleriniz.setItem(satirIndeks,sutunIndeks,QTableWidgetItem(str(sutunVeri)))
            self.tblStajyerleriniz.setHorizontalHeaderLabels(('İlan No','Öğrenci No','Ad Soyad','Tc No','Mail','Mesaj','Staj Başlangıç','Staj Bitiş','Firma Sicil No','Firma Adı','Firma Tel','Firma Mail'))
            conn.commit()

        def DOLDUR():
            sec=self.tblStajyerleriniz.selectedItems()
            self.txtogrAdSoyad.setText(sec[2].text())
            self.txtogrTcNo.setText(sec[3].text())
            self.txtogrMail.setText(sec[4].text())
            self.txtMesaj.setText(sec[5].text())
            _basTarih=QtCore.QDate.fromString(sec[6].text(), 'd.M.yyyy')
            self.dtBasTarih.setDate(_basTarih)
            _bitTarih=QtCore.QDate.fromString(sec[7].text(), 'd.M.yyyy')
            self.dtBitTarih.setDate(_bitTarih)
            self.txtfirmaSicilNo.setText(sec[8].text())
            self.txtfirmaAd.setText(sec[9].text())
            self.txtfirmaTel.setText(sec[10].text())
            self.txtfirmaMail.setText(sec[11].text())

        def TEMIZLE():
            self.txtogrTcNo.clear()
            self.txtogrMail.clear()
            self.txtogrAdSoyad.clear()
            self.txtDefterNo.clear()
            self.txtfirmaAd.clear()
            self.txtMesaj.clear()
            self.txtfirmaSicilNo.clear()
            self.txtfirmaTel.clear()
            self.txtfirmaMail.clear()

        def STAJBASLAT():
            if (len(self.txtogrTcNo.text())!=0):
                _tcNo=self.txtogrTcNo.text()
                curs.execute("select ogr_TcNo from staj_defterler where ogr_TcNo=%s"%(_tcNo))
                veri=curs.fetchone()
                if(veri):
                    QMessageBox.information(Dialog,"Stayyer Kabul İşlemi","Bu stajyerin defteri aktiftir.")
                else:
                    _koordorgrtTcNo=OGRTTCNOGETIR()
                    _firmaSicilNo=self.txtfirmaSicilNo.text()
                    curs.execute("INSERT INTO staj_defterler \
                                    (ogr_TcNo,koord_ogrtTcNo,firma_SicilNo,defter_durum) \
                                    VALUES (?,?,?,?)", \
                                    (_tcNo,_koordorgrtTcNo,_firmaSicilNo,'Aktif'))
                    conn.commit()
                    TEMIZLE()
                    DEFTERLER()
                    QMessageBox.information(Dialog,"Stayyer Kabul İşlemi","Stayyer kabul işlemi gerçekleşti.")
            else:
                QMessageBox.information(Dialog,"Stayyer Kabul İşlemi","Lütfen bir stajyer seçiniz.")


        def DEFTERSEC():
            sec=self.tblStajyerDefterleri.selectedItems()
            self.txtDefterNo.setText(sec[0].text())
            self.txtogrTcNo.setText(sec[1].text())
            self.txtogrAdSoyad.setText(sec[2].text())
            self.txtfirmaSicilNo.setText(sec[4].text())
            self.txtfirmaAd.setText(sec[5].text())

        def DEFTERLER():
            self.tblStajyerDefterleri.clear()
            self.tblStajyerDefterleri.setRowCount(0)

            veri=curs.execute("Select staj_defterler.defter_id, staj_defterler.ogr_TcNo, ogrenci_bilgi.ogr_AdSoyad, ogretmen_bilgi.ogrt_AdSoyad,staj_defterler.firma_SicilNo,firma_bilgi.Firma_Ad\
                                from  staj_defterler,firma_bilgi,ogretmen_bilgi,ogrenci_bilgi \
                                WHERE staj_defterler.koord_ogrtTcNo=ogretmen_bilgi.ogrt_TcNo and staj_defterler.ogr_TcNo=ogrenci_bilgi.ogr_TcNo \
                                and staj_defterler.firma_SicilNo=firma_bilgi.firma_SicilNo \
                                and Staj_defterler.defter_Durum='Aktif'")
            for satirIndeks, satirVeri in enumerate(veri):
                self.tblStajyerDefterleri.insertRow(satirIndeks)
                for sutunIndeks, sutunVeri in enumerate (satirVeri):
                    self.tblStajyerDefterleri.setItem(satirIndeks,sutunIndeks,QTableWidgetItem(str(sutunVeri)))
            self.tblStajyerDefterleri.setHorizontalHeaderLabels(('Defter No','Öğrenci Tc No','Öğrenci Ad Soyad','Koordinatör Öğretmen','Firma Sicil No','Firm Ad'))
            conn.commit()

        def DEFTERSIL():
            if (len(self.txtogrTcNo.text())!=0):
                 _defterNo=self.txtDefterNo.text()
                 msg1 = QMessageBox()
                 msg1.setIcon(QMessageBox.Question)
                 msg1.setText("Seçili stajyer defterini silmek istiyor musunuz?")
                 msg1.setWindowTitle("Defter sil")
                 msg1.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
                 cevap1=msg1.exec()
                 if cevap1==QMessageBox.Yes:
                     _defterNo=self.txtDefterNo.text()
                     try:
                         curs.execute("DELETE FROM staj_defterler WHERE defter_id='%s'" %(_defterNo))
                         conn.commit()    
                         TEMIZLE()
                         DEFTERLER()
                         QMessageBox.information(Dialog,"Defter Silme İşlemi","Stajyer çıkarıldı")
                     except Exception as Hata:
                         QMessageBox.warning(Dialog,"HATA","Şöyle bir hata meydana geldi : " +str(Hata))
            else:
                QMessageBox.warning(Dialog,"HATA","Lütfen silmek istediğiniz staj defteri seçiniz. ")


        Dialog.setObjectName("Dialog")
        Dialog.resize(972, 458)
        self.tblStajyerleriniz = QtWidgets.QTableWidget(Dialog)
        self.tblStajyerleriniz.setGeometry(QtCore.QRect(10, 70, 221, 381))
        self.tblStajyerleriniz.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.tblStajyerleriniz.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.tblStajyerleriniz.setObjectName("tblStajyerleriniz")
        self.tblStajyerleriniz.setColumnCount(12)
        self.tblStajyerleriniz.setRowCount(0)
        self.lblTcNo = QtWidgets.QLabel(Dialog)
        self.lblTcNo.setGeometry(QtCore.QRect(10, 10, 181, 16))
        self.lblTcNo.setObjectName("lblTcNo")
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(10, 50, 201, 16))
        self.label_2.setObjectName("label_2")
        self.txtogrTcNo = QtWidgets.QLineEdit(Dialog)
        self.txtogrTcNo.setGeometry(QtCore.QRect(360, 120, 113, 20))
        self.txtogrTcNo.setReadOnly(True)
        self.txtogrTcNo.setObjectName("txtogrTcNo")
        self.txtogrAdSoyad = QtWidgets.QLineEdit(Dialog)
        self.txtogrAdSoyad.setGeometry(QtCore.QRect(360, 150, 113, 20))
        self.txtogrAdSoyad.setReadOnly(True)
        self.txtogrAdSoyad.setObjectName("txtogrAdSoyad")
        self.txtfirmaSicilNo = QtWidgets.QLineEdit(Dialog)
        self.txtfirmaSicilNo.setGeometry(QtCore.QRect(312, 340, 161, 20))
        self.txtfirmaSicilNo.setReadOnly(True)
        self.txtfirmaSicilNo.setObjectName("txtfirmaSicilNo")
        self.txtfirmaAd = QtWidgets.QLineEdit(Dialog)
        self.txtfirmaAd.setGeometry(QtCore.QRect(312, 370, 161, 20))
        self.txtfirmaAd.setReadOnly(True)
        self.txtfirmaAd.setObjectName("txtfirmaAd")
        self.txtfirmaTel = QtWidgets.QLineEdit(Dialog)
        self.txtfirmaTel.setGeometry(QtCore.QRect(312, 400, 161, 20))
        self.txtfirmaTel.setReadOnly(True)
        self.txtfirmaTel.setObjectName("txtfirmaTel")
        self.btnDefterAktif = QtWidgets.QPushButton(Dialog)
        self.btnDefterAktif.setGeometry(QtCore.QRect(490, 420, 231, 31))
        self.btnDefterAktif.setObjectName("btnDefterAktif")
        self.btnDefterPasif = QtWidgets.QPushButton(Dialog)
        self.btnDefterPasif.setGeometry(QtCore.QRect(730, 420, 231, 31))
        self.btnDefterPasif.setObjectName("btnDefterPasif")
        self.tblStajyerDefterleri = QtWidgets.QTableWidget(Dialog)
        self.tblStajyerDefterleri.setGeometry(QtCore.QRect(480, 70, 481, 341))
        self.tblStajyerDefterleri.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.tblStajyerDefterleri.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.tblStajyerDefterleri.setObjectName("tblStajyerDefterleri")
        self.tblStajyerDefterleri.setColumnCount(6)
        self.tblStajyerDefterleri.setRowCount(0)
        self.label_3 = QtWidgets.QLabel(Dialog)
        self.label_3.setGeometry(QtCore.QRect(270, 120, 81, 20))
        self.label_3.setObjectName("label_3")
        self.label_4 = QtWidgets.QLabel(Dialog)
        self.label_4.setGeometry(QtCore.QRect(270, 150, 81, 16))
        self.label_4.setObjectName("label_4")
        self.txtDefterNo = QtWidgets.QLineEdit(Dialog)
        self.txtDefterNo.setGeometry(QtCore.QRect(360, 90, 113, 20))
        self.txtDefterNo.setReadOnly(True)
        self.txtDefterNo.setObjectName("txtDefterNo")
        self.label_5 = QtWidgets.QLabel(Dialog)
        self.label_5.setGeometry(QtCore.QRect(270, 90, 81, 21))
        self.label_5.setObjectName("label_5")
        self.label_6 = QtWidgets.QLabel(Dialog)
        self.label_6.setGeometry(QtCore.QRect(240, 60, 81, 16))
        self.label_6.setObjectName("label_6")
        self.label_7 = QtWidgets.QLabel(Dialog)
        self.label_7.setGeometry(QtCore.QRect(260, 340, 81, 16))
        self.label_7.setObjectName("label_7")
        self.txtfirmaMail = QtWidgets.QLineEdit(Dialog)
        self.txtfirmaMail.setGeometry(QtCore.QRect(312, 430, 161, 20))
        self.txtfirmaMail.setReadOnly(True)
        self.txtfirmaMail.setObjectName("txtfirmaMail")
        self.label_8 = QtWidgets.QLabel(Dialog)
        self.label_8.setGeometry(QtCore.QRect(260, 370, 81, 16))
        self.label_8.setObjectName("label_8")
        self.txtogrMail = QtWidgets.QLineEdit(Dialog)
        self.txtogrMail.setGeometry(QtCore.QRect(360, 180, 113, 20))
        self.txtogrMail.setReadOnly(True)
        self.txtogrMail.setObjectName("txtogrMail")
        self.label_9 = QtWidgets.QLabel(Dialog)
        self.label_9.setGeometry(QtCore.QRect(270, 180, 91, 21))
        self.label_9.setObjectName("label_9")
        self.label_10 = QtWidgets.QLabel(Dialog)
        self.label_10.setGeometry(QtCore.QRect(240, 310, 81, 16))
        self.label_10.setObjectName("label_10")
        self.label_11 = QtWidgets.QLabel(Dialog)
        self.label_11.setGeometry(QtCore.QRect(260, 400, 47, 13))
        self.label_11.setObjectName("label_11")
        self.label_12 = QtWidgets.QLabel(Dialog)
        self.label_12.setGeometry(QtCore.QRect(260, 430, 47, 13))
        self.label_12.setObjectName("label_12")
        self.label_13 = QtWidgets.QLabel(Dialog)
        self.label_13.setGeometry(QtCore.QRect(270, 250, 71, 16))
        self.label_13.setObjectName("label_13")
        self.llllll = QtWidgets.QLabel(Dialog)
        self.llllll.setGeometry(QtCore.QRect(270, 280, 71, 16))
        self.llllll.setObjectName("llllll")
        self.btnCikis = QtWidgets.QPushButton(Dialog)
        self.btnCikis.setGeometry(QtCore.QRect(890, 30, 75, 23))
        self.btnCikis.setObjectName("btnCikis")
        self.label_15 = QtWidgets.QLabel(Dialog)
        self.label_15.setGeometry(QtCore.QRect(480, 50, 201, 16))
        self.label_15.setObjectName("label_15")
        self.lblAdSoyad = QtWidgets.QLabel(Dialog)
        self.lblAdSoyad.setGeometry(QtCore.QRect(10, 30, 181, 16))
        self.lblAdSoyad.setObjectName("lblAdSoyad")
        self.dtBasTarih = QtWidgets.QDateEdit(Dialog)
        self.dtBasTarih.setGeometry(QtCore.QRect(360, 250, 110, 22))
        self.dtBasTarih.setObjectName("dtBasTarih")
        self.dtBitTarih = QtWidgets.QDateEdit(Dialog)
        self.dtBitTarih.setGeometry(QtCore.QRect(360, 280, 110, 22))
        self.dtBitTarih.setObjectName("dtBitTarih")
        self.txtMesaj = QtWidgets.QLineEdit(Dialog)
        self.txtMesaj.setGeometry(QtCore.QRect(312, 210, 161, 31))
        self.txtMesaj.setObjectName("txtMesaj")
        self.label_14 = QtWidgets.QLabel(Dialog)
        self.label_14.setGeometry(QtCore.QRect(270, 210, 61, 21))
        self.label_14.setObjectName("label_14")

        Dialog.setWindowFlags(Qt.WindowType.WindowSystemMenuHint);

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

        OGRTTCNOGETIR()
        STAJYERLER()
        DEFTERLER()
        self.tblStajyerleriniz.itemClicked.connect(DOLDUR)
        self.btnDefterAktif.clicked.connect(STAJBASLAT)
        self.tblStajyerDefterleri.itemClicked.connect(DEFTERSEC)
        self.btnDefterPasif.clicked.connect(DEFTERSIL)
        self.btnCikis.clicked.connect(kapat)


    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Defterler"))
        self.lblTcNo.setText(_translate("Dialog", "Öğretmen TCNO"))
        self.label_2.setText(_translate("Dialog", "Stajyer Olarak Kabul Edilen Öğrenciler"))
        self.btnDefterAktif.setText(_translate("Dialog", "Stajyer Defterini Aktif Et"))
        self.btnDefterPasif.setText(_translate("Dialog", "Stajyer Defterini Sil"))
        self.label_3.setText(_translate("Dialog", " TcNo"))
        self.label_4.setText(_translate("Dialog", "Ad Soyad"))
        self.label_5.setText(_translate("Dialog", "Deftre No"))
        self.label_6.setText(_translate("Dialog", "Stajyer Bilgileri"))
        self.label_7.setText(_translate("Dialog", "Sicil No"))
        self.label_8.setText(_translate("Dialog", "Ad"))
        self.label_9.setText(_translate("Dialog", "Mail"))
        self.label_10.setText(_translate("Dialog", "Firma Bilgileri"))
        self.label_11.setText(_translate("Dialog", "Telefon"))
        self.label_12.setText(_translate("Dialog", "Mail"))
        self.label_13.setText(_translate("Dialog", "Başlangıç Tarihi"))
        self.llllll.setText(_translate("Dialog", "Bitiş Tarihi"))
        self.btnCikis.setText(_translate("Dialog", "Çıkış"))
        self.label_15.setText(_translate("Dialog", "Stajyer Defteri Aktif Olan Öğrenciler"))
        self.lblAdSoyad.setText(_translate("Dialog", "Öğretmen Ad Soyad"))
        self.label_14.setText(_translate("Dialog", "Mesaj"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())

