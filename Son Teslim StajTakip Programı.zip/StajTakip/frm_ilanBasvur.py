# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\ahmet\Desktop\StajTakip\ekranlar\ilanBasvur.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import *
import sys
import sqlite3
import datetime
import frm_firmaMenu
global curs
global conn

conn=sqlite3.connect('stjyrtkp.sqlite')
curs=conn.cursor()

class Ui_Dialog(object):
    def setupUi(self, Dialog):

        def kapat():
            cevap=QMessageBox.question(Dialog,"Kapat","Kapatmak İstediğinize Emin misiniz?",\
                             QMessageBox.Yes | QMessageBox.No)
            if cevap== QMessageBox.Yes:
                window = QtWidgets.QMainWindow()
                ui = frm_firmaMenu.Ui_Dialog()
                ui.setupUi(window)
                window.show()
                Dialog.close()

        def ILANGETIR():
            self.tblStajyerilan.clear()
            self.tblBasvuru.clear()
            self.tblStajyerilan.setRowCount(0)
            self.tblBasvuru.setRowCount(0)
            
            veri=curs.execute("Select stajyer_ilan.ilan_id, stajyer_ilan.firma_SicilNo,firma_bilgi.firma_Ad, stajyer_ilan.ilan_Mesaj, stajyer_ilan.staj_BasTarih,stajyer_ilan.staj_BitTarih from firma_bilgi,stajyer_ilan WHERE stajyer_ilan.ilan_Durum='Aktif' and stajyer_ilan.firma_SicilNo=firma_bilgi.firma_SicilNo")
            for satirIndeks, satirVeri in enumerate(veri):
                self.tblStajyerilan.insertRow(satirIndeks)
                for sutunIndeks, sutunVeri in enumerate (satirVeri):
                    self.tblStajyerilan.setItem(satirIndeks,sutunIndeks,QTableWidgetItem(str(sutunVeri)))
            self.tblStajyerilan.setHorizontalHeaderLabels(('İlan No','Firma Sicil No','Firma Adı','Mesaj','Başlangıç Tarihi','Bitiş Tarihi'))
            conn.commit()

        def BASVURUGETIR():
            self.tblBasvuru.clear()
            self.tblBasvuru.setRowCount(0)
            veri=curs.execute("Select ilan_basvuru.basvuru_id,ilan_basvuru.ilan_id, firma_bilgi.firma_Ad, \
                                stajyer_ilan.ilan_Mesaj, stajyer_ilan.staj_BasTarih,stajyer_ilan.staj_BitTarih \
                                from ilan_basvuru,firma_bilgi,stajyer_ilan \
                                WHERE ilan_basvuru.ogr_TcNo=%s and stajyer_ilan.firma_SicilNo=firma_bilgi.firma_SicilNo \
                                and ilan_basvuru.ilan_id=stajyer_ilan.ilan_id"%(TCNOGETIR()))
            for satirIndeks, satirVeri in enumerate(veri):
                self.tblBasvuru.insertRow(satirIndeks)
                for sutunIndeks, sutunVeri in enumerate (satirVeri):
                    self.tblBasvuru.setItem(satirIndeks,sutunIndeks,QTableWidgetItem(str(sutunVeri)))
            self.tblBasvuru.setHorizontalHeaderLabels(('Başvuru No','İlan No','Firma Adı','Mesaj','Başlangıç Tarihi','Bitiş Tarihi'))
            conn.commit()

        def BASVURUSEC():
            sec=self.tblBasvuru.selectedItems()
            self.txtBasvuruid.setText(sec[0].text())

        def ILANSEC():
            sec=self.tblStajyerilan.selectedItems()
            self.txtilanid.setText(sec[0].text())
            self.txtSicilNo.setText(sec[1].text())
            self.txtFirmaAd.setText(sec[2].text())
            self.txtMesaj.setText(sec[3].text())
            _basTarih=QtCore.QDate.fromString(sec[4].text(), 'd.M.yyyy')
            self.dtBasTarih.setDate(_basTarih)
            _bitTarih=QtCore.QDate.fromString(sec[5].text(), 'd.M.yyyy')
            self.dtBitTarih.setDate(_bitTarih)

        def TCNOGETIR():
            curs.execute("SELECT ogrenci_oturum.ogr_TcNo,ogrenci_bilgi.ogr_AdSoyad FROM ogrenci_oturum,ogrenci_bilgi WHERE ogrenci_oturum.id = 1 \
                        and ogrenci_oturum.ogr_TcNo=ogrenci_bilgi.ogr_TcNo")
            deger=curs.fetchone()
            self.lblTcNo.setText("Merhaba " + str(deger[1])+".   Başvuru No:")
            return str(deger[0])
            
        def SILBASVURU():
            _basvuruNo=self.txtBasvuruid.text()
            if len(_basvuruNo)!=0:
                msg1 = QMessageBox()
                msg1.setIcon(QMessageBox.Question)
                msg1.setText("Başvurunuzu silmek istiyor musunuz?")
                msg1.setWindowTitle("Silme İşlemi")
                msg1.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
                cevap1=msg1.exec()
                if cevap1==QMessageBox.Yes:
                    try:
                        curs.execute("Delete from ilan_basvuru WHERE basvuru_id=%s"%(_basvuruNo))
                        conn.commit()
                        _basvuruNo=""    
                        BASVURUGETIR()
                        QMessageBox.information(Dialog,"Silme İşlemi","Başvurunuz silindi ")
                    except Exception as Hata:
                        QMessageBox.warning(Dialog,"HATA","Şöyle bir hata meydana geldi : " +str(Hata))
                    

        def BASVUR():
            if (len(self.txtilanid.text())!=0):
                _ilanid=self.txtilanid.text()
                veri=curs.execute("Select ilan_basvuru.basvuru_id \
                                from ilan_basvuru \
                                WHERE ilan_basvuru.ogr_TcNo=%s and ilan_basvuru.ilan_id=%s"%(TCNOGETIR(),_ilanid))
                deger=curs.fetchone()
                if deger:
                    QMessageBox.information(Dialog,"Uyarı","Daha önce bu ilana başvurdunuz.")
                else:
                    _ilanid=self.txtilanid.text()
                    _ogrTcNo=TCNOGETIR()
                    curs.execute("INSERT INTO ilan_basvuru \
                                    (ilan_id,ogr_TcNo) \
                                    VALUES (?,?)", \
                                    (_ilanid,_ogrTcNo))
                    conn.commit()         
                    ILANGETIR()
                    BASVURUGETIR()
                    QMessageBox.information(Dialog,"Kayıt İşlemi","Kayıt işlemi gerçekleşti.")
            else:
                QMessageBox.information(Dialog,"Kayıt İşlemi","Lütfen bir ilan seçiniz.")



        Dialog.setObjectName("Dialog")
        Dialog.resize(685, 642)
        self.tblStajyerilan = QtWidgets.QTableWidget(Dialog)
        self.tblStajyerilan.setGeometry(QtCore.QRect(10, 40, 661, 192))
        self.tblStajyerilan.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.tblStajyerilan.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.tblStajyerilan.setObjectName("tblStajyerilan")
        self.tblStajyerilan.setColumnCount(6)
        self.tblStajyerilan.setRowCount(0)
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(20, 10, 121, 16))
        self.label.setObjectName("label")
        self.tblBasvuru = QtWidgets.QTableWidget(Dialog)
        self.tblBasvuru.setGeometry(QtCore.QRect(10, 440, 661, 192))
        self.tblBasvuru.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.tblBasvuru.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.tblBasvuru.setObjectName("tblBasvuru")
        self.tblBasvuru.setColumnCount(6)
        self.tblBasvuru.setRowCount(0)
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(10, 410, 121, 16))
        self.label_2.setObjectName("label_2")
        self.txtilanid = QtWidgets.QLineEdit(Dialog)
        self.txtilanid.setEnabled(True)
        self.txtilanid.setGeometry(QtCore.QRect(120, 250, 121, 20))
        self.txtilanid.setReadOnly(True)
        self.txtilanid.setObjectName("txtilanid")
        self.txtMesaj = QtWidgets.QLineEdit(Dialog)
        self.txtMesaj.setGeometry(QtCore.QRect(460, 310, 211, 41))
        self.txtMesaj.setReadOnly(True)
        self.txtMesaj.setObjectName("txtMesaj")
        self.dtBasTarih = QtWidgets.QDateEdit(Dialog)
        self.dtBasTarih.setGeometry(QtCore.QRect(120, 280, 121, 22))
        self.dtBasTarih.setReadOnly(True)
        self.dtBasTarih.setObjectName("dtBasTarih")
        self.dtBitTarih = QtWidgets.QDateEdit(Dialog)
        self.dtBitTarih.setEnabled(True)
        self.dtBitTarih.setGeometry(QtCore.QRect(120, 310, 121, 22))
        self.dtBitTarih.setReadOnly(True)
        self.dtBitTarih.setObjectName("dtBitTarih")
        self.txtSicilNo = QtWidgets.QLineEdit(Dialog)
        self.txtSicilNo.setGeometry(QtCore.QRect(460, 250, 211, 20))
        self.txtSicilNo.setReadOnly(True)
        self.txtSicilNo.setObjectName("txtSicilNo")
        self.txtFirmaAd = QtWidgets.QLineEdit(Dialog)
        self.txtFirmaAd.setGeometry(QtCore.QRect(460, 280, 211, 20))
        self.txtFirmaAd.setReadOnly(True)
        self.txtFirmaAd.setObjectName("txtFirmaAd")
        self.btnBasvur = QtWidgets.QPushButton(Dialog)
        self.btnBasvur.setGeometry(QtCore.QRect(120, 340, 121, 23))
        self.btnBasvur.setObjectName("btnBasvur")
        self.btnSil = QtWidgets.QPushButton(Dialog)
        self.btnSil.setGeometry(QtCore.QRect(560, 400, 111, 23))
        self.btnSil.setObjectName("btnSil")
        self.txtBasvuruid = QtWidgets.QLineEdit(Dialog)
        self.txtBasvuruid.setGeometry(QtCore.QRect(430, 400, 113, 20))
        self.txtBasvuruid.setReadOnly(True)
        self.txtBasvuruid.setObjectName("txtBasvuruid")
        self.lblTcNo = QtWidgets.QLabel(Dialog)
        self.lblTcNo.setAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignTrailing|QtCore.Qt.AlignVCenter)
        self.lblTcNo.setGeometry(QtCore.QRect(160, 400, 261, 20))
        self.lblTcNo.setObjectName("lblTcNo")
        self.btnCikis = QtWidgets.QPushButton(Dialog)
        self.btnCikis.setGeometry(QtCore.QRect(590, 10, 75, 23))
        self.btnCikis.setObjectName("btnCikis")
        self.label_4 = QtWidgets.QLabel(Dialog)
        self.label_4.setGeometry(QtCore.QRect(10, 250, 91, 16))
        self.label_4.setObjectName("label_4")
        self.label_5 = QtWidgets.QLabel(Dialog)
        self.label_5.setGeometry(QtCore.QRect(10, 280, 91, 16))
        self.label_5.setObjectName("label_5")
        self.label_6 = QtWidgets.QLabel(Dialog)
        self.label_6.setGeometry(QtCore.QRect(10, 310, 91, 16))
        self.label_6.setObjectName("label_6")
        self.label_7 = QtWidgets.QLabel(Dialog)
        self.label_7.setGeometry(QtCore.QRect(320, 250, 91, 16))
        self.label_7.setObjectName("label_7")
        self.label_8 = QtWidgets.QLabel(Dialog)
        self.label_8.setGeometry(QtCore.QRect(320, 280, 91, 16))
        self.label_8.setObjectName("label_8")
        self.label_9 = QtWidgets.QLabel(Dialog)
        self.label_9.setGeometry(QtCore.QRect(320, 310, 91, 16))
        self.label_9.setObjectName("label_9")

        Dialog.setWindowFlags(Qt.WindowType.WindowSystemMenuHint);

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
        ILANGETIR()
        TCNOGETIR()
        BASVURUGETIR()
        self.tblStajyerilan.itemClicked.connect(ILANSEC)
        self.tblBasvuru.itemClicked.connect(BASVURUSEC)
        self.btnBasvur.clicked.connect(BASVUR)
        self.btnSil.clicked.connect(SILBASVURU)
        self.btnCikis.clicked.connect(kapat)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Staj İlan Başvurusu"))
        self.label.setText(_translate("Dialog", "Aktif İlanlar"))
        self.label_2.setText(_translate("Dialog", "Başvurulan İlanlar"))
        self.btnBasvur.setText(_translate("Dialog", "İlana Başvur"))
        self.btnSil.setText(_translate("Dialog", "Başvurumu Sil"))
        self.lblTcNo.setText(_translate("Dialog", " "))
        self.btnCikis.setText(_translate("Dialog", "Cikis"))
        self.label_4.setText(_translate("Dialog", "İlan No"))
        self.label_5.setText(_translate("Dialog", "Başlangıç Tarihi"))
        self.label_6.setText(_translate("Dialog", "Bitiş Tarihi"))
        self.label_7.setText(_translate("Dialog", "Firma Sicil No"))
        self.label_8.setText(_translate("Dialog", "Firma Adı"))
        self.label_9.setText(_translate("Dialog", "Mesaj"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())

