# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\ahmet\Desktop\StajTakip\ekranlar\defteronayla.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import *
import sys
import sqlite3
import datetime
import frm_ogrtMenu
global curs
global conn

conn=sqlite3.connect('stjyrtkp.sqlite')
curs=conn.cursor()


class Ui_Dialog(object):
    def setupUi(self, Dialog):

        def kapat():
            cevap=QMessageBox.question(Dialog,"Kapat","Kapatmak İstediğinize Emin misiniz?",\
                             QMessageBox.Yes | QMessageBox.No)
            if cevap== QMessageBox.Yes:
                window = QtWidgets.QMainWindow()
                ui = frm_ogrtMenu.Ui_Dialog()
                ui.setupUi(window)
                window.show()
                Dialog.close()

        def TCNOGETIR():
            curs.execute("SELECT ogretmen_oturum.ogrt_TcNo,ogretmen_bilgi.ogrt_AdSoyad FROM ogretmen_oturum,ogretmen_bilgi WHERE ogretmen_oturum.id = 1 \
                                and ogretmen_oturum.ogrt_TcNo=ogretmen_bilgi.ogrt_TcNo")
            deger=curs.fetchone()
            self.label_9.setText("Koordinatör Öğretmen : " +str(deger[1]))
            return str(deger[0])

        def DEFTERGETIR():
            self.tblGonderilenDefterler.clear()
            self.tblGonderilenDefterler.setRowCount(0)

            veri=curs.execute("Select staj_Onay.ogr_TcNo,ogrenci_bilgi.ogr_AdSoyad,ogrenci_bilgi.ogr_No,staj_defterler.firma_SicilNo,\
                                firma_bilgi.firma_Ad,staj_Onay.onay_Durum,staj_Onay.onay_id, staj_Onay.defter_id,staj_Onay.onay_Mesaj \
                                from firma_bilgi,ogrenci_bilgi,staj_defterler,staj_onay\
                                WHERE staj_onay.defter_id=staj_defterler.defter_id and staj_defterler.firma_SicilNo=firma_bilgi.firma_SicilNo\
                                and staj_onay.ogr_TcNo=ogrenci_bilgi.ogr_TcNo")
            for satirIndeks, satirVeri in enumerate(veri):
                self.tblGonderilenDefterler.insertRow(satirIndeks)
                for sutunIndeks, sutunVeri in enumerate (satirVeri):
                    self.tblGonderilenDefterler.setItem(satirIndeks,sutunIndeks,QTableWidgetItem(str(sutunVeri)))
            self.tblGonderilenDefterler.setHorizontalHeaderLabels(('Tc No','Ad Soyad','Öğrenci No','Firma Sicil No','Firma Ad','Onay Durum','Onay No','Defter No','Mesaj'))
            conn.commit()

        def DEFTERICERIK():
            self.tblDefterIcerik.clear()
            self.tblDefterIcerik.setRowCount(0)
            sec=self.tblGonderilenDefterler.selectedItems()
            self.txtogrTcNo.setText(sec[0].text())
            self.txtAdSoyad.setText(sec[1].text())
            self.txtOnayDurum.setText(sec[5].text())
            self.txtOnayNo.setText(sec[6].text())
            self.txtDefterNo.setText(sec[7].text())
            self.txtMesaj.setText(sec[8].text())
            _defterNo=sec[7].text()
            veri=curs.execute("Select isbasi_Tarih,gunluk_Yapilanlar,gunluk_id,defter_id from defter_rapor Where defter_id=%s"%_defterNo)
            for satirIndeks, satirVeri in enumerate(veri):
                self.tblDefterIcerik.insertRow(satirIndeks)
                for sutunIndeks, sutunVeri in enumerate (satirVeri):
                    self.tblDefterIcerik.setItem(satirIndeks,sutunIndeks,QTableWidgetItem(str(sutunVeri)))
            self.tblDefterIcerik.setHorizontalHeaderLabels(('İş Günü','Yapılan Faaliyetler','İşbaşı No','Defter No'))
            conn.commit()

        def ONAYLA():
            if (len(self.txtOnayNo.text())!=0):
                _onayNo=self.txtOnayNo.text()
                msg1 = QMessageBox()
                msg1.setIcon(QMessageBox.Question)
                msg1.setText("Stajı onaylamak istiyor musunuz?")
                msg1.setWindowTitle("Staj Onaylama İşlemi")
                msg1.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
                cevap1=msg1.exec()
                if cevap1==QMessageBox.Yes:
                    _mesaj=self.txtMesaj.text()
                    curs.execute("UPDATE staj_Onay set onay_Durum='Onaylandı', onay_Mesaj=? where onay_id=?",(_mesaj,_onayNo))
                    conn.commit()
                    self.txtAdSoyad.clear()
                    self.txtDefterNo.clear()
                    self.txtMesaj.clear()
                    self.txtogrTcNo.clear()
                    self.txtOnayDurum.clear()
                    self.txtOnayNo.clear()
                    DEFTERGETIR()
                    QMessageBox.information(Dialog,"Staj Onay İşlemi","Staj onayı gerçekleşti.")
            else:
                QMessageBox.information(Dialog,"Staj Onay İşlemi","Lütfen bir staj defteri seçiniz.")

        def GERIGONDER():
            if (len(self.txtOnayNo.text())!=0):
                _onayNo=self.txtOnayNo.text()
                msg1 = QMessageBox()
                msg1.setIcon(QMessageBox.Question)
                msg1.setText("Staj defterini geri göndermek istiyor musunuz?")
                msg1.setWindowTitle("Staj Geri Gönderme İşlemi")
                msg1.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
                cevap1=msg1.exec()
                if cevap1==QMessageBox.Yes:
                    _mesaj=self.txtMesaj.text()
                    curs.execute("UPDATE staj_Onay set onay_Durum='Pasif', onay_Mesaj=? where onay_id=?",(_mesaj,_onayNo))
                    conn.commit()
                    self.txtAdSoyad.clear()
                    self.txtDefterNo.clear()
                    self.txtMesaj.clear()
                    self.txtogrTcNo.clear()
                    self.txtOnayDurum.clear()
                    self.txtOnayNo.clear()
                    DEFTERGETIR()
                    QMessageBox.information(Dialog,"Staj Geri Gönderim İşlemi","Staj defteri geri gönderildi.")
            else:
                QMessageBox.information(Dialog,"Staj Geri Gönderim İşlemi","Lütfen bir staj defteri seçiniz.")

        Dialog.setObjectName("Dialog")
        Dialog.resize(899, 331)
        self.tblGonderilenDefterler = QtWidgets.QTableWidget(Dialog)
        self.tblGonderilenDefterler.setGeometry(QtCore.QRect(10, 50, 161, 271))
        self.tblGonderilenDefterler.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.tblGonderilenDefterler.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.tblGonderilenDefterler.setObjectName("tblGonderilenDefterler")
        self.tblGonderilenDefterler.setColumnCount(9)
        self.tblGonderilenDefterler.setRowCount(0)
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(20, 30, 151, 16))
        self.label.setObjectName("label")
        self.tblDefterIcerik = QtWidgets.QTableWidget(Dialog)
        self.tblDefterIcerik.setGeometry(QtCore.QRect(180, 50, 451, 271))
        self.tblDefterIcerik.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.tblDefterIcerik.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.tblDefterIcerik.setObjectName("tblDefterIcerik")
        self.tblDefterIcerik.setColumnCount(4)
        self.tblDefterIcerik.setRowCount(0)
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(200, 30, 151, 16))
        self.label_2.setObjectName("label_2")
        self.btnOnayla = QtWidgets.QPushButton(Dialog)
        self.btnOnayla.setGeometry(QtCore.QRect(640, 230, 251, 41))
        self.btnOnayla.setObjectName("btnOnayla")
        self.btnGeriGonder = QtWidgets.QPushButton(Dialog)
        self.btnGeriGonder.setGeometry(QtCore.QRect(640, 280, 251, 41))
        self.btnGeriGonder.setObjectName("btnGeriGonder")
        self.txtDefterNo = QtWidgets.QLineEdit(Dialog)
        self.txtDefterNo.setGeometry(QtCore.QRect(720, 80, 171, 20))
        self.txtDefterNo.setReadOnly(True)
        self.txtDefterNo.setObjectName("txtDefterNo")
        self.txtogrTcNo = QtWidgets.QLineEdit(Dialog)
        self.txtogrTcNo.setGeometry(QtCore.QRect(720, 110, 171, 20))
        self.txtogrTcNo.setReadOnly(True)
        self.txtogrTcNo.setObjectName("txtogrTcNo")
        self.txtOnayDurum = QtWidgets.QLineEdit(Dialog)
        self.txtOnayDurum.setGeometry(QtCore.QRect(720, 170, 171, 21))
        self.txtOnayDurum.setReadOnly(True)
        self.txtOnayDurum.setObjectName("txtOnayDurum")
        self.txtOnayNo = QtWidgets.QLineEdit(Dialog)
        self.txtOnayNo.setGeometry(QtCore.QRect(720, 50, 171, 20))
        self.txtOnayNo.setReadOnly(True)
        self.txtOnayNo.setObjectName("txtOnayNo")
        self.label_3 = QtWidgets.QLabel(Dialog)
        self.label_3.setGeometry(QtCore.QRect(640, 50, 61, 21))
        self.label_3.setObjectName("label_3")
        self.txtAdSoyad = QtWidgets.QLineEdit(Dialog)
        self.txtAdSoyad.setGeometry(QtCore.QRect(720, 140, 171, 20))
        self.txtAdSoyad.setReadOnly(True)
        self.txtAdSoyad.setObjectName("txtAdSoyad")
        self.btnCikis = QtWidgets.QPushButton(Dialog)
        self.btnCikis.setGeometry(QtCore.QRect(820, 10, 75, 23))
        self.btnCikis.setObjectName("btnCikis")
        self.txtMesaj = QtWidgets.QLineEdit(Dialog)
        self.txtMesaj.setGeometry(QtCore.QRect(720, 200, 171, 20))
        self.txtMesaj.setObjectName("txtMesaj")
        self.label_4 = QtWidgets.QLabel(Dialog)
        self.label_4.setGeometry(QtCore.QRect(640, 110, 71, 21))
        self.label_4.setObjectName("label_4")
        self.label_5 = QtWidgets.QLabel(Dialog)
        self.label_5.setGeometry(QtCore.QRect(640, 140, 71, 21))
        self.label_5.setObjectName("label_5")
        self.label_6 = QtWidgets.QLabel(Dialog)
        self.label_6.setGeometry(QtCore.QRect(640, 170, 71, 21))
        self.label_6.setObjectName("label_6")
        self.label_7 = QtWidgets.QLabel(Dialog)
        self.label_7.setGeometry(QtCore.QRect(640, 80, 61, 21))
        self.label_7.setObjectName("label_7")
        self.label_8 = QtWidgets.QLabel(Dialog)
        self.label_8.setGeometry(QtCore.QRect(640, 200, 81, 21))
        self.label_8.setObjectName("label_8")
        self.label_9 = QtWidgets.QLabel(Dialog)
        self.label_9.setGeometry(QtCore.QRect(20, 10, 250, 16))
        self.label_9.setObjectName("label_9")

        Dialog.setWindowFlags(Qt.WindowType.WindowSystemMenuHint);

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
        self.tblGonderilenDefterler.itemClicked.connect(DEFTERICERIK)
        self.btnOnayla.clicked.connect(ONAYLA)
        self.btnGeriGonder.clicked.connect(GERIGONDER)
        self.btnCikis.clicked.connect(kapat)

        TCNOGETIR()
        DEFTERGETIR()

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Defter Onayla"))
        self.label.setText(_translate("Dialog", "Tamamlanan Staj Defterleri"))
        self.label_2.setText(_translate("Dialog", "Staj Defteri İçeriği"))
        self.btnOnayla.setText(_translate("Dialog", "Onayla"))
        self.btnGeriGonder.setText(_translate("Dialog", "Geri Gönder"))
        self.label_3.setText(_translate("Dialog", "Onay No"))
        self.btnCikis.setText(_translate("Dialog", "Çıkış"))
        self.label_4.setText(_translate("Dialog", "Öğrenci Tc No"))
        self.label_5.setText(_translate("Dialog", "Ad Soyad"))
        self.label_6.setText(_translate("Dialog", "Onay Durum"))
        self.label_7.setText(_translate("Dialog", "Defter No"))
        self.label_8.setText(_translate("Dialog", "Mesajınızı Girin:"))
        self.label_9.setText(_translate("Dialog", "Koordinatör Öğretmen:"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())

