# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\ahmet\Desktop\StajTakip\ekranlar\defterim.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import *
import sys
import sqlite3
import datetime
import frm_firmaMenu

global curs
global conn

conn=sqlite3.connect('stjyrtkp.sqlite')
curs=conn.cursor()

class Ui_Dialog(object):
    def setupUi(self, Dialog):

        def kapat():
            cevap=QMessageBox.question(Dialog,"Kapat","Kapatmak İstediğinize Emin misiniz?",\
                             QMessageBox.Yes | QMessageBox.No)
            if cevap== QMessageBox.Yes:
                window = QtWidgets.QMainWindow()
                ui = frm_firmaMenu.Ui_Dialog()
                ui.setupUi(window)
                window.show()
                Dialog.close()

        def TCNOGETIR():
            curs.execute("SELECT ogrenci_oturum.ogr_TcNo,ogrenci_bilgi.ogr_AdSoyad FROM ogrenci_oturum,ogrenci_bilgi WHERE ogrenci_oturum.id = 1 \
                                and ogrenci_oturum.ogr_TcNo=ogrenci_bilgi.ogr_TcNo")
            deger=curs.fetchone()
            self.txtogrTcNo.setText(str(deger[0]))
            self.txtogrAdSoyad.setText(str(deger[1]))
            return str(deger[0])

        def ZAMANAYAR():
            self.dtisbasiTarih.setDate(datetime.datetime.now())
           

        def BILGIGETIR():
            curs.execute("SELECT staj_defterler.defter_id, ogrenci_bilgi.ogr_No, ogrenci_bilgi.ogr_Mail, \
                            staj_defterler.firma_SicilNo, firma_bilgi.firma_Ad, firma_bilgi.firma_TelNo, firma_bilgi.firma_Mail, \
                            ogretmen_bilgi.ogrt_AdSoyad, ogretmen_bilgi.ogrt_Mail \
                            from ogretmen_bilgi,ogrenci_bilgi, firma_bilgi,staj_defterler \
                            WHERE staj_defterler.ogr_TcNo=%s and staj_defterler.ogr_TcNo=ogrenci_bilgi.ogr_TcNo \
                            and staj_defterler.koord_ogrtTcNo=ogretmen_bilgi.ogrt_TcNo and staj_defterler.firma_SicilNo=firma_bilgi.firma_SicilNo"%(self.txtogrTcNo.text()))
            veriler=curs.fetchone()
            if veriler:
                self.txtDefterNo.setText(str(veriler[0]))
                self.txtOkulNo.setText(str(veriler[1]))
                self.txtogrMail.setText(str(veriler[2]))
                self.txtSicilNo.setText(str(veriler[3]))
                self.txtfirmaAd.setText(str(veriler[4]))
                self.txtTelNo.setText(str(veriler[5]))
                self.txtfirmaMail.setText(str(veriler[6]))
                self.txtogrtAdSoyad.setText(str(veriler[7]))
                self.txtogrtMail.setText(str(veriler[8]))

        def DEFTERIMDOLDUR():
            self.tblDefterim.clear()
            self.tblDefterim.setRowCount(0)

            veri=curs.execute("Select defter_rapor.gunluk_id, defter_rapor.defter_id,defter_rapor.isbasi_Tarih, defter_rapor.gunluk_Yapilanlar \
                                from defter_rapor, staj_defterler \
                                WHERE defter_rapor.defter_id=staj_defterler.defter_id and Staj_defterler.defter_Durum='Aktif' order by defter_rapor.isbasi_Tarih Asc")
            _durum=curs.fetchone()
            if not (_durum):
                self.btnKaydet.setEnabled(False)
                self.btnGuncelle.setEnabled(False)
                self.btnGonder.setEnabled(False)
                self.btnSil.setEnabled(False)
            for satirIndeks, satirVeri in enumerate(veri):
                self.tblDefterim.insertRow(satirIndeks)
                for sutunIndeks, sutunVeri in enumerate (satirVeri):
                    self.tblDefterim.setItem(satirIndeks,sutunIndeks,QTableWidgetItem(str(sutunVeri)))
            self.tblDefterim.setHorizontalHeaderLabels(('İşbaşı No','Defter No','İşbaşı Tarih','Yapılan Faaliyetler'))
            conn.commit()


        def ISBASIKAYDET():
            if len(self.txtDefterNo.text())!=0:
                _isbasiTarih=self.dtisbasiTarih.text()
                curs.execute("select isbasi_Tarih from defter_rapor where isbasi_Tarih='"+_isbasiTarih+"'")
                veri=curs.fetchone()
                if(veri):
                    QMessageBox.information(Dialog,"İşbaşı Giriş İşlemi","Bu tarih daha önce kayıt edilmiş.")
                else:
                    _defterNo=self.txtDefterNo.text()
                    _isbasiTarih=self.dtisbasiTarih.text()
                    _yapilanlar=self.txtYapilanlar.text()
                    curs.execute("Insert into defter_rapor (defter_id,isbasi_Tarih,gunluk_Yapilanlar) VALUES(?,?,?)",(_defterNo,_isbasiTarih,_yapilanlar))
                    conn.commit()
                    self.txtYapilanlar.clear()
                    DEFTERIMDOLDUR()
                    QMessageBox.information(Dialog,"İşbaşı Giriş İşlemi","İşbaşı giriş işlemi gerçekleşti.")
            else:
                QMessageBox.information(Dialog,"İşbaşı Giriş İşlemi","Lütfen staj defterinizi öğretmeninizden aktif ettiriniz.")



        def GONDER():
            msg1 = QMessageBox()
            msg1.setIcon(QMessageBox.Question)
            msg1.setText("Seçili stajyer defterini kapatıp öğretmeninize göndermek istiyor musunuz?")
            msg1.setWindowTitle("Defter Kapat ve Gönder")
            msg1.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
            cevap1=msg1.exec()
            if cevap1==QMessageBox.Yes:
                _defterNo=self.txtDefterNo.text()
                _ogrTcNo=self.txtogrTcNo.text()
                curs.execute("Insert into staj_onay (defter_id,onay_Durum,ogr_TcNo) values (?,?,?)",(_defterNo,'Pasif',_ogrTcNo))
                conn.commit()
                curs.execute("Update staj_defterler set defter_durum=? where defter_id=?",('Pasif',_defterNo))
                conn.commit()
                QMessageBox.information(Dialog,"Defter Kapat ve Gönder","Staj defteriniz kapatıldı ve öğretmeninize gönderildi.")
                BILGIGETIR()
                DEFTERIMDOLDUR()

        def SIL():
            if (len(self.txtisbasiNo.text())!=0):
                 msg1 = QMessageBox()
                 msg1.setIcon(QMessageBox.Question)
                 msg1.setText("Seçili stajyer defterini silmek istiyor musunuz?")
                 msg1.setWindowTitle("İsbasi Silme İşlemi")
                 msg1.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
                 cevap1=msg1.exec()
                 if cevap1==QMessageBox.Yes:
                     _isbasiNo=self.txtisbasiNo.text()
                     try:
                         curs.execute("DELETE FROM defter_rapor WHERE gunluk_id='%s'" %(_isbasiNo))
                         conn.commit()    
                         DEFTERIMDOLDUR()
                         QMessageBox.information(Dialog,"İsbasi Silme İşlemi","İşgünü silindi")
                     except Exception as Hata:
                         QMessageBox.warning(Dialog,"HATA","Şöyle bir hata meydana geldi : " +str(Hata))
            else:
                QMessageBox.warning(Dialog,"HATA","Lütfen silmek istediğiniz işgününü seçiniz. ")


        def ISBASISEC():
            sec=self.tblDefterim.selectedItems()
            self.txtisbasiNo.setText(sec[0].text())
            self.dtisbasiTarih.setDate(QtCore.QDate.fromString(sec[2].text(), 'd.M.yyyy'))
            self.txtYapilanlar.setText(sec[3].text())

        def GUNCELLE():
            if len(self.txtDefterNo.text())!=0:
                _isbasiTarih=self.dtisbasiTarih.text()
                curs.execute("select isbasi_Tarih from defter_rapor where isbasi_Tarih='"+_isbasiTarih+"'")
                veri=curs.fetchone()
                if(veri):
                    QMessageBox.information(Dialog,"İşbaşı Giriş İşlemi","Bu tarih daha önce kayıt edilmiş.")
                else:
                    if(len(self.txtisbasiNo.text())!=0):
                        cevap=QMessageBox.question(Dialog,"Güncelleme","Kaydı güncellemek istiyor musunuz?",\
                                         QMessageBox.Yes | QMessageBox.No)
                        if cevap== QMessageBox.Yes:
                             _isbasiNo=self.txtisbasiNo.text()
                             _isbasiTarih=self.dtisbasiTarih.text()
                             _yapilanlar=self.txtYapilanlar.text()
                             curs.execute("Update defter_rapor set isbasi_Tarih=?,gunluk_yapilanlar=? where gunluk_id=?",(_isbasiTarih,_yapilanlar,_isbasiNo))
                             conn.commit()
                             DEFTERIMDOLDUR()
                             QMessageBox.information(Dialog,"İşbaşı Güncelleme İşlemi","İşbaşı güncelleme işlemi gerçekleşti.")
                    else:
                        QMessageBox.information(Dialog,"İşbaşı Güncelleme İşlemi","Güncellemek için işbaşı seçmelisiniz.")

        Dialog.setObjectName("Dialog")
        Dialog.resize(771, 549)
        self.txtDefterNo = QtWidgets.QLineEdit(Dialog)
        self.txtDefterNo.setGeometry(QtCore.QRect(130, 50, 131, 20))
        self.txtDefterNo.setReadOnly(True)
        self.txtDefterNo.setObjectName("txtDefterNo")
        self.tblDefterim = QtWidgets.QTableWidget(Dialog)
        self.tblDefterim.setGeometry(QtCore.QRect(10, 350, 751, 192))
        self.tblDefterim.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.tblDefterim.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.tblDefterim.setObjectName("tblDefterim")
        self.tblDefterim.setColumnCount(4)
        self.tblDefterim.setRowCount(0)
        self.lblMesaj = QtWidgets.QLabel(Dialog)
        self.lblMesaj.setGeometry(QtCore.QRect(710, 10, 47, 13))
        self.lblMesaj.setText("")
        self.lblMesaj.setObjectName("lblMesaj")
        self.label_3 = QtWidgets.QLabel(Dialog)
        self.label_3.setGeometry(QtCore.QRect(30, 50, 71, 21))
        self.label_3.setObjectName("label_3")
        self.txtogrTcNo = QtWidgets.QLineEdit(Dialog)
        self.txtogrTcNo.setGeometry(QtCore.QRect(130, 80, 131, 20))
        self.txtogrTcNo.setReadOnly(True)
        self.txtogrTcNo.setObjectName("txtogrTcNo")
        self.label_4 = QtWidgets.QLabel(Dialog)
        self.label_4.setGeometry(QtCore.QRect(30, 80, 71, 21))
        self.label_4.setObjectName("label_4")
        self.txtogrAdSoyad = QtWidgets.QLineEdit(Dialog)
        self.txtogrAdSoyad.setGeometry(QtCore.QRect(130, 110, 131, 20))
        self.txtogrAdSoyad.setReadOnly(True)
        self.txtogrAdSoyad.setObjectName("txtogrAdSoyad")
        self.label_5 = QtWidgets.QLabel(Dialog)
        self.label_5.setGeometry(QtCore.QRect(30, 110, 71, 21))
        self.label_5.setObjectName("label_5")
        self.label_6 = QtWidgets.QLabel(Dialog)
        self.label_6.setGeometry(QtCore.QRect(30, 10, 71, 21))
        self.label_6.setObjectName("label_6")
        self.btnCikis = QtWidgets.QPushButton(Dialog)
        self.btnCikis.setGeometry(QtCore.QRect(680, 40, 75, 23))
        self.btnCikis.setObjectName("btnCikis")
        self.txtOkulNo = QtWidgets.QLineEdit(Dialog)
        self.txtOkulNo.setGeometry(QtCore.QRect(130, 140, 131, 20))
        self.txtOkulNo.setReadOnly(True)
        self.txtOkulNo.setObjectName("txtOkulNo")
        self.label_7 = QtWidgets.QLabel(Dialog)
        self.label_7.setGeometry(QtCore.QRect(30, 140, 71, 21))
        self.label_7.setObjectName("label_7")
        self.label_8 = QtWidgets.QLabel(Dialog)
        self.label_8.setGeometry(QtCore.QRect(30, 170, 71, 21))
        self.label_8.setObjectName("label_8")
        self.txtogrMail = QtWidgets.QLineEdit(Dialog)
        self.txtogrMail.setGeometry(QtCore.QRect(130, 170, 131, 20))
        self.txtogrMail.setReadOnly(True)
        self.txtogrMail.setObjectName("txtogrMail")
        self.label_9 = QtWidgets.QLabel(Dialog)
        self.label_9.setGeometry(QtCore.QRect(300, 10, 71, 21))
        self.label_9.setObjectName("label_9")
        self.label_10 = QtWidgets.QLabel(Dialog)
        self.label_10.setGeometry(QtCore.QRect(550, 110, 161, 21))
        self.label_10.setObjectName("label_10")
        self.txtTelNo = QtWidgets.QLineEdit(Dialog)
        self.txtTelNo.setGeometry(QtCore.QRect(380, 110, 131, 20))
        self.txtTelNo.setReadOnly(True)
        self.txtTelNo.setObjectName("txtTelNo")
        self.txtSicilNo = QtWidgets.QLineEdit(Dialog)
        self.txtSicilNo.setGeometry(QtCore.QRect(380, 50, 131, 20))
        self.txtSicilNo.setReadOnly(True)
        self.txtSicilNo.setObjectName("txtSicilNo")
        self.label_12 = QtWidgets.QLabel(Dialog)
        self.label_12.setGeometry(QtCore.QRect(280, 140, 71, 21))
        self.label_12.setObjectName("label_12")
        self.label_13 = QtWidgets.QLabel(Dialog)
        self.label_13.setGeometry(QtCore.QRect(280, 50, 71, 21))
        self.label_13.setObjectName("label_13")
        self.txtfirmaAd = QtWidgets.QLineEdit(Dialog)
        self.txtfirmaAd.setGeometry(QtCore.QRect(380, 80, 131, 20))
        self.txtfirmaAd.setReadOnly(True)
        self.txtfirmaAd.setObjectName("txtfirmaAd")
        self.txtfirmaMail = QtWidgets.QLineEdit(Dialog)
        self.txtfirmaMail.setGeometry(QtCore.QRect(380, 140, 131, 20))
        self.txtfirmaMail.setReadOnly(True)
        self.txtfirmaMail.setObjectName("txtfirmaMail")
        self.label_14 = QtWidgets.QLabel(Dialog)
        self.label_14.setGeometry(QtCore.QRect(280, 80, 71, 21))
        self.label_14.setObjectName("label_14")
        self.label_15 = QtWidgets.QLabel(Dialog)
        self.label_15.setGeometry(QtCore.QRect(280, 110, 71, 21))
        self.label_15.setObjectName("label_15")
        self.label_16 = QtWidgets.QLabel(Dialog)
        self.label_16.setGeometry(QtCore.QRect(530, 150, 71, 21))
        self.label_16.setObjectName("label_16")
        self.label_17 = QtWidgets.QLabel(Dialog)
        self.label_17.setGeometry(QtCore.QRect(530, 180, 71, 21))
        self.label_17.setObjectName("label_17")
        self.txtogrtMail = QtWidgets.QLineEdit(Dialog)
        self.txtogrtMail.setGeometry(QtCore.QRect(630, 180, 131, 20))
        self.txtogrtMail.setReadOnly(True)
        self.txtogrtMail.setObjectName("txtogrtMail")
        self.txtogrtAdSoyad = QtWidgets.QLineEdit(Dialog)
        self.txtogrtAdSoyad.setGeometry(QtCore.QRect(630, 150, 131, 20))
        self.txtogrtAdSoyad.setReadOnly(True)
        self.txtogrtAdSoyad.setObjectName("txtogrtAdSoyad")
        self.dtisbasiTarih = QtWidgets.QDateEdit(Dialog)
        self.dtisbasiTarih.setGeometry(QtCore.QRect(140, 230, 110, 22))
        self.dtisbasiTarih.setObjectName("dtisbasiTarih")
        self.txtYapilanlar = QtWidgets.QLineEdit(Dialog)
        self.txtYapilanlar.setGeometry(QtCore.QRect(140, 270, 621, 41))
        self.txtYapilanlar.setObjectName("txtYapilanlar")
        self.label_11 = QtWidgets.QLabel(Dialog)
        self.label_11.setGeometry(QtCore.QRect(30, 230, 71, 21))
        self.label_11.setObjectName("label_11")
        self.label_18 = QtWidgets.QLabel(Dialog)
        self.label_18.setGeometry(QtCore.QRect(30, 270, 47, 13))
        self.label_18.setObjectName("label_18")
        self.btnKaydet = QtWidgets.QPushButton(Dialog)
        self.btnKaydet.setGeometry(QtCore.QRect(10, 320, 141, 23))
        self.btnKaydet.setObjectName("btnKaydet")
        self.btnGuncelle = QtWidgets.QPushButton(Dialog)
        self.btnGuncelle.setGeometry(QtCore.QRect(160, 320, 141, 23))
        self.btnGuncelle.setObjectName("btnGuncelle")
        self.btnSil = QtWidgets.QPushButton(Dialog)
        self.btnSil.setGeometry(QtCore.QRect(310, 320, 141, 23))
        self.btnSil.setObjectName("btnSil")
        self.txtisbasiNo = QtWidgets.QLineEdit(Dialog)
        self.txtisbasiNo.setGeometry(QtCore.QRect(380, 230, 131, 20))
        self.txtisbasiNo.setReadOnly(True)
        self.txtisbasiNo.setObjectName("txtisbasiNo")
        self.label_19 = QtWidgets.QLabel(Dialog)
        self.label_19.setGeometry(QtCore.QRect(280, 230, 47, 13))
        self.label_19.setObjectName("label_19")
        self.btnGonder = QtWidgets.QPushButton(Dialog)
        self.btnGonder.setGeometry(QtCore.QRect(560, 320, 201, 23))
        self.btnGonder.setObjectName("btnGonder")

        Dialog.setWindowFlags(Qt.WindowType.WindowSystemMenuHint);
        

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

        TCNOGETIR()
        ZAMANAYAR()
        BILGIGETIR()
        DEFTERIMDOLDUR()
        self.btnKaydet.clicked.connect(ISBASIKAYDET)
        self.btnGuncelle.clicked.connect(GUNCELLE)
        self.btnSil.clicked.connect(SIL)
        self.btnGonder.clicked.connect(GONDER)
        self.tblDefterim.itemClicked.connect(ISBASISEC)
        self.btnCikis.clicked.connect(kapat)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Staj Defterim"))
        self.label_3.setText(_translate("Dialog", "Defter No"))
        self.label_4.setText(_translate("Dialog", "Tc No"))
        self.label_5.setText(_translate("Dialog", "Ad Soyad"))
        self.label_6.setText(_translate("Dialog", "Stajyer Bilgileri"))
        self.btnCikis.setText(_translate("Dialog", "Çıkış"))
        self.label_7.setText(_translate("Dialog", "Okul No"))
        self.label_8.setText(_translate("Dialog", "Mail"))
        self.label_9.setText(_translate("Dialog", "Firma Bilgileri"))
        self.label_10.setText(_translate("Dialog", "Koordinatör Öğretmen"))
        self.label_12.setText(_translate("Dialog", "Mail"))
        self.label_13.setText(_translate("Dialog", "Sicil No"))
        self.label_14.setText(_translate("Dialog", "Firma Adı"))
        self.label_15.setText(_translate("Dialog", "Telefon No"))
        self.label_16.setText(_translate("Dialog", "Ad Soyad"))
        self.label_17.setText(_translate("Dialog", "Mail"))
        self.label_11.setText(_translate("Dialog", "İşbaşı Tarih"))
        self.label_18.setText(_translate("Dialog", "Yapılanlar"))
        self.btnKaydet.setText(_translate("Dialog", "Kaydet"))
        self.btnGuncelle.setText(_translate("Dialog", "Güncelle"))
        self.btnSil.setText(_translate("Dialog", "Sil"))
        self.label_19.setText(_translate("Dialog", "İşbaşı No"))
        self.btnGonder.setText(_translate("Dialog", "Defteri Kapat ve Gönder"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())

