# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\ahmet\Desktop\StajTakip\ekranlar\Stajyerilan.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import *
import sys
import sqlite3
import datetime
import frm_firmaMenu
global curs
global conn

conn=sqlite3.connect('stjyrtkp.sqlite')
curs=conn.cursor()
global mesaj

class Ui_Dialog(object):
    
    def setupUi(self, Dialog):

        def kapat():
            cevap=QMessageBox.question(Dialog,"Kapat","Kapatmak İstediğinize Emin misiniz?",\
                             QMessageBox.Yes | QMessageBox.No)
            if cevap== QMessageBox.Yes:
                window = QtWidgets.QMainWindow()
                ui = frm_firmaMenu.Ui_Dialog()
                ui.setupUi(window)
                window.show()
                Dialog.close()

        def TEMIZLE():
            self.txtMesaj.clear()
            self.txtOgrSayi.setText("1")
            self.txtilanNo.setText('0')

        def ZAMANAYAR():
            self.dtBasTarih.setDate(datetime.datetime.now())
            self.dtBitTarih.setDate(datetime.datetime.now())

        def GirisKontrol():
            global mesaj
            _sicilNo=self.txtSicilNo.text()
            _ogrSayi=self.txtOgrSayi.text()
            deger=True
            if len(_sicilNo)==0:
                mesaj+="Sicil No "
                deger=False
            if _ogrSayi<1:
                mesaj+="Stajyer Sayısı "
                deger=False
            return deger

        def SIL():
            msg1 = QMessageBox()
            msg1.setIcon(QMessageBox.Question)
            msg1.setText("Kaydı silmek istiyor musunuz?")
            msg1.setWindowTitle("Silme İşlemi")
            msg1.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
            cevap1=msg1.exec()
            if cevap1==QMessageBox.Yes:
                ilanno=self.txtilanNo.text()
                try:
                    curs.execute("DELETE FROM stajyer_ilan WHERE ilan_Id='%s'" %(ilanno))
                    conn.commit()
                    TEMIZLE()
                    GETIR()
                    QMessageBox.information(Dialog,"Silme İşlemi","Kayıt silindi ")
                except Exception as Hata:
                    QMessageBox.warning(Dialog,"HATA","Şöyle bir hata meydana geldi : " +str(Hata))

        def DOLDUR():
            sec=self.tblGoster.selectedItems()
            self.txtilanNo.setText(sec[0].text())
            self.txtMesaj.setText(sec[1].text())
            self.txtOgrSayi.setText(sec[2].text())
            _basTarih=QtCore.QDate.fromString(sec[3].text(), 'd.M.yyyy')
            self.dtBasTarih.setDate(_basTarih)
            _bitTarih=QtCore.QDate.fromString(sec[4].text(), 'd.M.yyyy')
            self.dtBitTarih.setDate(_bitTarih)
            _iDurum=sec[5].text()
            if(_iDurum=='Aktif'):
                self.rbAktif.setChecked(True)
            else:
                self.rbPasif.setChecked(True)

        def GETIR():
            self.tblGoster.clear()
            self.tblGoster.setRowCount(0)
            veri=curs.execute("Select firma_SicilNo from firma_oturum Where id=1")
            _sicilNo=curs.fetchone()
            self.txtSicilNo.setText(str(_sicilNo[0]))
            veri=curs.execute("Select ilan_id, ilan_Mesaj, ihtiyac_OgrSayi, staj_BasTarih, staj_BitTarih, ilan_Durum from stajyer_ilan where firma_SicilNo= %s"%(_sicilNo))
            for satirIndeks, satirVeri in enumerate(veri):
                self.tblGoster.insertRow(satirIndeks)
                for sutunIndeks, sutunVeri in enumerate (satirVeri):
                    self.tblGoster.setItem(satirIndeks,sutunIndeks,QTableWidgetItem(str(sutunVeri)))
            self.tblGoster.setHorizontalHeaderLabels(('İlan No','Mesaj','Stajyer İhtiyacı','Başlangıç Tarihi','Bitiş Tarihi', 'İlan Durumu'))
            conn.commit()

        def RBUTTONDURUM():
            _durum='Aktif'
            if self.rbAktif.isChecked():
                _durum='Aktif'
            else:
                _durum='Pasif'
            return _durum

        def EKLE():
            global mesaj
            mesaj=" "
            _sicilNo=self.txtSicilNo.text()
            _ogrSayi=self.txtOgrSayi.text()
            _basTarih=self.dtBasTarih.text()
            _bitTarih=self.dtBitTarih.text()
            _mesaj=self.txtMesaj.text()
            
            curs.execute("INSERT INTO stajyer_ilan \
                             (ihtiyac_OgrSayi,staj_BasTarih,staj_BitTarih,ilan_Mesaj,firma_SicilNo,ilan_Durum) \
                             VALUES (?,?,?,?,?,?)", \
                             (_ogrSayi,_basTarih,_bitTarih,_mesaj,_sicilNo,RBUTTONDURUM()))
            conn.commit()
            TEMIZLE()
            GETIR()
            QMessageBox.information(Dialog,"Kayıt İşlemi","Kayıt işlemi gerçekleşti.")
            conn.close()

        def GUNCELLE():
            cevap=QMessageBox.question(Dialog,"Güncelleme","Kaydı güncellemek istiyor musunuz?",\
                                 QMessageBox.Yes | QMessageBox.No)
            if cevap== QMessageBox.Yes:
                try:
                    _ilanid=self.txtilanNo.text()
                    _sicilNo=self.txtSicilNo.text()
                    _ogrSayi=self.txtOgrSayi.text()
                    _basTarih=self.dtBasTarih.text()
                    _bitTarih=self.dtBitTarih.text()
                    _mesaj=self.txtMesaj.text()
                    curs.execute("UPDATE stajyer_ilan SET ihtiyac_OgrSayi=?, staj_BasTarih=?, staj_BitTarih=?, ilan_Mesaj=?, ilan_Durum=? WHERE ilan_id=?", (_ogrSayi,_basTarih,_bitTarih,_mesaj,RBUTTONDURUM(),_ilanid))
                    conn.commit()
                    QMessageBox.information(Dialog,"Güncelleme","Kayıt Güncelleme Başarılı")
                    TEMIZLE()
                    GETIR()
                except Exception as Hata:
                    QMessageBox.warning(Dialog,"HATA",str(Hata))
            else:
                QMessageBox.warning(Dialog,"HATA","Güncellme iptal edildi")

        Dialog.setObjectName("Dialog")
        Dialog.resize(429, 493)
        self.txtOgrSayi = QtWidgets.QLineEdit(Dialog)
        self.txtOgrSayi.setGeometry(QtCore.QRect(242, 80, 181, 20))
        self.txtOgrSayi.setObjectName("txtOgrSayi")
        self.dtBasTarih = QtWidgets.QDateEdit(Dialog)
        self.dtBasTarih.setGeometry(QtCore.QRect(240, 110, 181, 22))
        self.dtBasTarih.setObjectName("dtBasTarih")
        self.dtBitTarih = QtWidgets.QDateEdit(Dialog)
        self.dtBitTarih.setGeometry(QtCore.QRect(239, 140, 181, 22))
        self.dtBitTarih.setObjectName("dtBitTarih")
        self.txtMesaj = QtWidgets.QLineEdit(Dialog)
        self.txtMesaj.setGeometry(QtCore.QRect(240, 170, 181, 51))
        self.txtMesaj.setObjectName("txtMesaj")
        self.txtSicilNo = QtWidgets.QLineEdit(Dialog)
        self.txtSicilNo.setEnabled(False)
        self.txtSicilNo.setGeometry(QtCore.QRect(242, 50, 181, 20))
        self.txtSicilNo.setObjectName("txtSicilNo")
        self.txtilanNo = QtWidgets.QLineEdit(Dialog)
        self.txtilanNo.setEnabled(False)
        self.txtilanNo.setGeometry(QtCore.QRect(242, 20, 181, 20))
        self.txtilanNo.setObjectName("txtilanNo")
        self.rbAktif = QtWidgets.QRadioButton(Dialog)
        self.rbAktif.setGeometry(QtCore.QRect(240, 230, 82, 17))
        self.rbAktif.setChecked(True)
        self.rbAktif.setObjectName("rbAktif")
        self.rbPasif = QtWidgets.QRadioButton(Dialog)
        self.rbPasif.setGeometry(QtCore.QRect(340, 230, 82, 17))
        self.rbPasif.setChecked(False)
        self.rbPasif.setObjectName("rbPasif")
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(60, 30, 47, 13))
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(60, 60, 47, 13))
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(Dialog)
        self.label_3.setGeometry(QtCore.QRect(60, 90, 111, 16))
        self.label_3.setObjectName("label_3")
        self.label_4 = QtWidgets.QLabel(Dialog)
        self.label_4.setGeometry(QtCore.QRect(60, 120, 101, 16))
        self.label_4.setObjectName("label_4")
        self.label_5 = QtWidgets.QLabel(Dialog)
        self.label_5.setGeometry(QtCore.QRect(60, 150, 101, 16))
        self.label_5.setObjectName("label_5")
        self.label_6 = QtWidgets.QLabel(Dialog)
        self.label_6.setGeometry(QtCore.QRect(60, 180, 101, 16))
        self.label_6.setObjectName("label_6")
        self.tblGoster = QtWidgets.QTableWidget(Dialog)
        self.tblGoster.setGeometry(QtCore.QRect(10, 290, 411, 192))
        self.tblGoster.setObjectName("tblGoster")
        self.tblGoster.setColumnCount(6)
        self.tblGoster.setRowCount(0)
        self.tblGoster.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.tblGoster.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.btnKaydet = QtWidgets.QPushButton(Dialog)
        self.btnKaydet.setGeometry(QtCore.QRect(90, 260, 81, 23))
        self.btnKaydet.setObjectName("btnKaydet")
        self.btnTemizle = QtWidgets.QPushButton(Dialog)
        self.btnTemizle.setGeometry(QtCore.QRect(10, 260, 75, 23))
        self.btnTemizle.setObjectName("btnTemizle")
        self.btnGuncelle = QtWidgets.QPushButton(Dialog)
        self.btnGuncelle.setGeometry(QtCore.QRect(180, 260, 75, 23))
        self.btnGuncelle.setObjectName("btnGuncelle")
        self.btnSil = QtWidgets.QPushButton(Dialog)
        self.btnSil.setGeometry(QtCore.QRect(260, 260, 75, 23))
        self.btnSil.setObjectName("btnSil")
        self.btnCikis = QtWidgets.QPushButton(Dialog)
        self.btnCikis.setGeometry(QtCore.QRect(340, 260, 75, 23))
        self.btnCikis.setObjectName("btnCikis")
        Dialog.setWindowFlags(Qt.WindowType.WindowSystemMenuHint);

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

        self.btnTemizle.clicked.connect(TEMIZLE)
        self.btnKaydet.clicked.connect(EKLE)
        self.rbAktif.toggled.connect(RBUTTONDURUM)
        self.rbPasif.toggled.connect(RBUTTONDURUM)
        self.tblGoster.itemClicked.connect(DOLDUR)
        self.btnGuncelle.clicked.connect(GUNCELLE)
        self.btnSil.clicked.connect(SIL)
        self.btnCikis.clicked.connect(kapat)
        ZAMANAYAR()
        GETIR()

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Stajyer Alım İlanı"))
        self.rbAktif.setText(_translate("Dialog", "Aktif"))
        self.rbPasif.setText(_translate("Dialog", "Pasif"))
        self.label.setText(_translate("Dialog", "İlan no"))
        self.label_2.setText(_translate("Dialog", "Sicil No"))
        self.label_3.setText(_translate("Dialog", "Stajyer Sayısı"))
        self.label_4.setText(_translate("Dialog", "Başlangıç Tarihi"))
        self.label_5.setText(_translate("Dialog", "Bitiş Tarihi"))
        self.label_6.setText(_translate("Dialog", "Mesaj"))
        self.btnKaydet.setText(_translate("Dialog", "Kaydet"))
        self.btnTemizle.setText(_translate("Dialog", "Temizle"))
        self.btnGuncelle.setText(_translate("Dialog", "Güncelle"))
        self.btnSil.setText(_translate("Dialog", "Sil"))
        self.btnCikis.setText(_translate("Dialog", "Çıkış"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())

