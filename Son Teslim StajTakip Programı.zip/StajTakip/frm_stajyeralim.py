# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\ahmet\Desktop\StajTakip\ekranlar\stajyeralim.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import *
import sys
import sqlite3
import datetime
import frm_firmaMenu
global curs
global conn

conn=sqlite3.connect('stjyrtkp.sqlite')
curs=conn.cursor()
global ilanno

class Ui_Dialog(object):
    def setupUi(self, Dialog):

        def kapat():
            cevap=QMessageBox.question(Dialog,"Kapat","Kapatmak İstediğinize Emin misiniz?",\
                             QMessageBox.Yes | QMessageBox.No)
            if cevap== QMessageBox.Yes:
                window = QtWidgets.QMainWindow()
                ui = frm_firmaMenu.Ui_Dialog()
                ui.setupUi(window)
                window.show()
                Dialog.close()

        def SICILNOGETIR():
            curs.execute("SELECT firma_oturum.firma_SicilNo,firma_bilgi.firma_Ad FROM firma_oturum,firma_bilgi WHERE firma_oturum.id = 1 \
                            and firma_oturum.firma_SicilNo=firma_bilgi.firma_SicilNo")
            deger=curs.fetchone()
            self.lblSicilNo.setText(str(deger[0]))
            self.lblFirmaAd.setText(str(deger[1]))
            return str(deger[0])

        def ILANGETIR():
            self.tblilanlar.clear()
            self.tblilanlar.setRowCount(0)
            
            veri=curs.execute("Select stajyer_ilan.ilan_id, stajyer_ilan.ilan_Mesaj, stajyer_ilan.staj_BasTarih,stajyer_ilan.staj_BitTarih \
                                from stajyer_ilan \
                                WHERE stajyer_ilan.ilan_Durum='Aktif' and stajyer_ilan.firma_SicilNo=%s"%(SICILNOGETIR()))
            for satirIndeks, satirVeri in enumerate(veri):
                self.tblilanlar.insertRow(satirIndeks)
                for sutunIndeks, sutunVeri in enumerate (satirVeri):
                    self.tblilanlar.setItem(satirIndeks,sutunIndeks,QTableWidgetItem(str(sutunVeri)))
            self.tblilanlar.setHorizontalHeaderLabels(('İlan No','Mesaj','Başlangıç Tarihi','Bitiş Tarihi'))
            conn.commit()

        def SECOGRENCI():
            global ilanno
            veriler=self.tblBasvurular.selectedItems()
            self.txtOgrNo.setText(veriler[1].text())
            self.txtAdSoyad.setText(veriler[2].text())
            self.txtTcNo.setText(veriler[3].text())
            self.txtMail.setText(veriler[4].text())
            ilanno=veriler[0].text()

        def STAJYERAL():
            if (len(self.txtTcNo.text())!=0):
                _tcNo=self.txtTcNo.text()
                curs.execute("INSERT INTO ilan_alim \
                                (ilan_id,ogr_TcNo) \
                                VALUES (?,?)", \
                                (ilanno,_tcNo))
                conn.commit()
                curs.execute("UPDATE ogrenci_bilgi set ogr_StajDurum='Pasif' where ogrenci_bilgi.ogr_TcNo=%s"%_tcNo)
                conn.commit()
                BASVURUGETIR()
                self.txtTcNo.clear()
                self.txtMail.clear()
                self.txtAdSoyad.clear()
                self.txtOgrNo.clear()
                QMessageBox.information(Dialog,"Stayyer Kabul İşlemi","Stayyer kabul işlemi gerçekleşti.")
            else:
                QMessageBox.information(Dialog,"Stayyer Kabul İşlemi","Lütfen bir stajyer seçiniz.")

        def STAJYERLER():
            global ilanno
            self.tblStajyerleriniz.clear()
            self.tblStajyerleriniz.setRowCount(0)
            
            veri=curs.execute("Select ilan_alim.ilan_id, ogrenci_bilgi.ogr_No,ogrenci_bilgi.ogr_AdSoyad,ilan_alim.ogr_TcNo,ogrenci_bilgi.ogr_Mail \
                                from  ilan_alim, ogrenci_bilgi \
                                WHERE ilan_alim.ilan_id=%s and ilan_alim.ogr_TcNo=ogrenci_bilgi.ogr_TcNo"%(ilanno))
            for satirIndeks, satirVeri in enumerate(veri):
                self.tblStajyerleriniz.insertRow(satirIndeks)
                for sutunIndeks, sutunVeri in enumerate (satirVeri):
                    self.tblStajyerleriniz.setItem(satirIndeks,sutunIndeks,QTableWidgetItem(str(sutunVeri)))
            self.tblStajyerleriniz.setHorizontalHeaderLabels(('İlan No','Öğrenci No','Ad Soyad','Tc No','Mail'))
            conn.commit()

        def BASVURUGETIR():
            global ilanno
            self.tblBasvurular.clear()
            self.tblBasvurular.setRowCount(0)
            veriler=self.tblilanlar.selectedItems()
            _ilanid=veriler[0].text()
            ilanno=_ilanid
            veri=curs.execute("Select ilan_basvuru.ilan_id, ogrenci_bilgi.ogr_No,ogrenci_bilgi.ogr_AdSoyad,ilan_basvuru.ogr_TcNo,ogrenci_bilgi.ogr_Mail \
                                from  ilan_basvuru, ogrenci_bilgi \
                                WHERE ilan_basvuru.ilan_id=%s and ilan_basvuru.ogr_TcNo=ogrenci_bilgi.ogr_TcNo \
                                and ogrenci_bilgi.ogr_StajDurum='Aktif'"%(_ilanid))
                              
            for satirIndeks, satirVeri in enumerate(veri):
                self.tblBasvurular.insertRow(satirIndeks)
                for sutunIndeks, sutunVeri in enumerate (satirVeri):
                    self.tblBasvurular.setItem(satirIndeks,sutunIndeks,QTableWidgetItem(str(sutunVeri)))
            self.tblBasvurular.setHorizontalHeaderLabels(('İlan No','Okul No','Adı Soyadı','Tc No','Mail Adresi'))
            conn.commit()
            STAJYERLER()

        def SILOGRENCIGETIR():
            global ilanno
            veriler=self.tblStajyerleriniz.selectedItems()
            self.txtOgrNo.setText(veriler[1].text())
            self.txtAdSoyad.setText(veriler[2].text())
            self.txtTcNo.setText(veriler[3].text())
            self.txtMail.setText(veriler[4].text())
            ilanno=veriler[0].text()


        def STAJYERCIKART():
            if (len(self.txtTcNo.text())!=0):
                _tcno=self.txtTcNo.text()
                veri=curs.execute("select ogr_TcNo from ilan_alim where ogr_TcNo=%s"%(_tcno))
                bak=curs.fetchone()
                if not bak:
                    QMessageBox.information(Dialog,"Stajyer Çıkartma İşlemi","Stajyer işe alınmamış.")
                else:
                    msg1 = QMessageBox()
                    msg1.setIcon(QMessageBox.Question)
                    msg1.setText("Stajyeri çıkartmak istiyor musunuz?")
                    msg1.setWindowTitle("Stajyer Çıkartma İşlemi")
                    msg1.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
                    cevap1=msg1.exec()
                    if cevap1==QMessageBox.Yes:
                        tcno=self.txtTcNo.text()
                        try:
                            curs.execute("DELETE FROM ilan_alim WHERE ogr_TcNo='%s'" %(tcno))
                            conn.commit()     
                            curs.execute("UPDATE ogrenci_bilgi set ogr_StajDurum='Aktif' where ogrenci_bilgi.ogr_TcNo=%s"%tcNo)
                            conn.commit()
                            BASVURUGETIR()
                            STAJYERLER()
                            self.txtTcNo.clear()
                            self.txtMail.clear()
                            self.txtAdSoyad.clear()
                            self.txtOgrNo.clear()
                            QMessageBox.information(Dialog,"Stajyer Çıkartma İşlemi","Stajyer çıkarıldı")
                        except Exception as Hata:
                            QMessageBox.warning(Dialog,"HATA","Şöyle bir hata meydana geldi : " +str(Hata))
            else:
                QMessageBox.warning(Dialog,"HATA","Lütfen çıkartmak istediğiniz stajyerinizi seçiniz. ")

            

        Dialog.setObjectName("Dialog")
        Dialog.resize(844, 460)
        self.tblilanlar = QtWidgets.QTableWidget(Dialog)
        self.tblilanlar.setGeometry(QtCore.QRect(10, 70, 391, 192))
        self.tblilanlar.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.tblilanlar.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.tblilanlar.setObjectName("tblilanlar")
        self.tblilanlar.setColumnCount(4)
        self.tblilanlar.setRowCount(0)
        self.lblFirmaAd = QtWidgets.QLabel(Dialog)
        self.lblFirmaAd.setGeometry(QtCore.QRect(10, 30, 150, 13))
        self.lblFirmaAd.setObjectName("lblFirmaAd")
        self.lblSicilNo = QtWidgets.QLabel(Dialog)
        self.lblSicilNo.setGeometry(QtCore.QRect(10, 10, 47, 13))
        self.lblSicilNo.setObjectName("lblSicilNo")
        self.tblBasvurular = QtWidgets.QTableWidget(Dialog)
        self.tblBasvurular.setGeometry(QtCore.QRect(420, 70, 411, 192))
        self.tblBasvurular.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.tblBasvurular.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.tblBasvurular.setObjectName("tblBasvurular")
        self.tblBasvurular.setColumnCount(5)
        self.tblBasvurular.setRowCount(0)
        self.label_3 = QtWidgets.QLabel(Dialog)
        self.label_3.setGeometry(QtCore.QRect(10, 50, 91, 16))
        self.label_3.setObjectName("label_3")
        self.label_4 = QtWidgets.QLabel(Dialog)
        self.label_4.setGeometry(QtCore.QRect(420, 50, 141, 16))
        self.label_4.setObjectName("label_4")
        self.txtAdSoyad = QtWidgets.QLineEdit(Dialog)
        self.txtAdSoyad.setGeometry(QtCore.QRect(210, 320, 191, 20))
        self.txtAdSoyad.setAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignTrailing|QtCore.Qt.AlignVCenter)
        self.txtAdSoyad.setObjectName("txtAdSoyad")
        self.txtTcNo = QtWidgets.QLineEdit(Dialog)
        self.txtTcNo.setGeometry(QtCore.QRect(210, 290, 191, 20))
        self.txtTcNo.setAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignTrailing|QtCore.Qt.AlignVCenter)
        self.txtTcNo.setObjectName("txtTcNo")
        self.txtOgrNo = QtWidgets.QLineEdit(Dialog)
        self.txtOgrNo.setGeometry(QtCore.QRect(210, 350, 191, 20))
        self.txtOgrNo.setAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignTrailing|QtCore.Qt.AlignVCenter)
        self.txtOgrNo.setObjectName("txtOgrNo")
        self.txtMail = QtWidgets.QLineEdit(Dialog)
        self.txtMail.setGeometry(QtCore.QRect(210, 380, 191, 20))
        self.txtMail.setAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignTrailing|QtCore.Qt.AlignVCenter)
        self.txtMail.setObjectName("txtMail")
        self.tblStajyerleriniz = QtWidgets.QTableWidget(Dialog)
        self.tblStajyerleriniz.setGeometry(QtCore.QRect(420, 290, 411, 161))
        self.tblStajyerleriniz.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.tblStajyerleriniz.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.tblStajyerleriniz.setObjectName("tblStajyerleriniz")
        self.tblStajyerleriniz.setColumnCount(5)
        self.tblStajyerleriniz.setRowCount(0)
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(420, 270, 251, 16))
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(10, 270, 171, 16))
        self.label_2.setObjectName("label_2")
        self.label_5 = QtWidgets.QLabel(Dialog)
        self.label_5.setGeometry(QtCore.QRect(120, 290, 47, 21))
        self.label_5.setObjectName("label_5")
        self.label_6 = QtWidgets.QLabel(Dialog)
        self.label_6.setGeometry(QtCore.QRect(120, 320, 47, 21))
        self.label_6.setObjectName("label_6")
        self.label_7 = QtWidgets.QLabel(Dialog)
        self.label_7.setGeometry(QtCore.QRect(120, 380, 47, 21))
        self.label_7.setObjectName("label_7")
        self.label_8 = QtWidgets.QLabel(Dialog)
        self.label_8.setGeometry(QtCore.QRect(120, 350, 71, 21))
        self.label_8.setObjectName("label_8")
        self.btnIptal = QtWidgets.QPushButton(Dialog)
        self.btnIptal.setGeometry(QtCore.QRect(270, 410, 131, 41))
        self.btnIptal.setObjectName("btnIptal")
        self.btnKaydet = QtWidgets.QPushButton(Dialog)
        self.btnKaydet.setGeometry(QtCore.QRect(120, 410, 131, 41))
        self.btnKaydet.setObjectName("btnKaydet")
        self.btnCikis = QtWidgets.QPushButton(Dialog)
        self.btnCikis.setGeometry(QtCore.QRect(724, 10, 101, 31))
        self.btnCikis.setObjectName("btnCikis")
        Dialog.setWindowFlags(Qt.WindowType.WindowSystemMenuHint);

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

        SICILNOGETIR()
        ILANGETIR()
        self.tblilanlar.itemClicked.connect(BASVURUGETIR)
        self.tblBasvurular.itemClicked.connect(SECOGRENCI)
        self.tblStajyerleriniz.itemClicked.connect(SILOGRENCIGETIR)
        self.btnKaydet.clicked.connect(STAJYERAL)
        self.btnIptal.clicked.connect(STAJYERCIKART)
        self.btnCikis.clicked.connect(kapat)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Stajyer Alım"))
        self.lblFirmaAd.setText(_translate("Dialog", "Firma Ad"))
        self.lblSicilNo.setText(_translate("Dialog", "Sicil No"))
        self.label_3.setText(_translate("Dialog", "İlanlarınız"))
        self.label_4.setText(_translate("Dialog", "Başvuran Öğrenciler"))
        self.label.setText(_translate("Dialog", "Staja Kabul Edilen Öğrenciler"))
        self.label_2.setText(_translate("Dialog", "Seçilen Öğreci Bilgileri"))
        self.label_5.setText(_translate("Dialog", "Tc No"))
        self.label_6.setText(_translate("Dialog", "Ad Soyad"))
        self.label_7.setText(_translate("Dialog", "Mail"))
        self.label_8.setText(_translate("Dialog", "Öğrenci No"))
        self.btnIptal.setText(_translate("Dialog", "Stajyerliği iptal et"))
        self.btnKaydet.setText(_translate("Dialog", "Stajyer olarak al"))
        self.btnCikis.setText(_translate("Dialog", "Çıkış"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())

